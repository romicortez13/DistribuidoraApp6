package aiep.rominacortez.semana_5;

public class CalculoDespacho {
    public double calcDespacho(double Distancia, double ValorCompra){
        double CostoDespacho1 = 150; // Almacena un valor que puede cambiar.Esta variable cuenta con el valor del despacho por kilómetro recorrido para compras entre $25.000 y $49.999
        double CostoDespacho2 = 300; //Almacena un valor que puede cambiar. Esta variable cuenta con el valor del despacho por kilómetro recorrido para compras menores a $25.000
        double ValorDespacho; // Almacena un valor que puede cambiar.Esta variable almacenará el resultado del cálculo del valor del despacho de la compra según los kilómetros recorridos.
        double TotalCompra = 0; // Almacena un valor que puede cambiar.Esta variable almacenará el valor total de la compra incluyendo el cargo por despacho

        System.out.println("----Distribucion de Alimentos---- "); // Encabezado de texto de salida en la terminal, imprime mensaje

        if(Distancia <= 20){ // Si la compra es mayor a 50000 dentro de la distancia de 20km el despacho sera gratis. Condicional que verifica
            if(ValorCompra > 49999){ // Condicional
                System.out.println("Despacho Gratis"); // si el valor de la compra es mayor a 50.000 el despacho es gratis
                TotalCompra = ValorCompra;
            }
            if(ValorCompra >= 25000 && ValorCompra <= 49999 ) { // si el valor de la compra es entre 25000 y 49999 se cobrara una tarifa de $150 x km recorrido
                ValorDespacho = CostoDespacho1 * Distancia; // Calcula el valor sumando costodespacho+distancia
                TotalCompra = ValorCompra + ValorDespacho; //muestra el total
                System.out.print("Se cobrara una tarifa de $150 por kilometro recorrido "); // imprime
                System.out.print("El total de la compra incluyendo despacho es de: $" + TotalCompra); // imprime
            }
            if (ValorCompra < 25000){ // si la compra es menor a 25000, se cobrara una tarifa de $300 por km recorrido
                ValorDespacho = CostoDespacho2 * Distancia;
                TotalCompra = ValorCompra + ValorDespacho;
                System.out.println("Se cobrara una tarifa de $300 por kilometro recorrido");
                System.out.print("El total de la compra incluyendo despacho es de: $" + TotalCompra);
            }
        }
        return TotalCompra;
    }
}
