package aiep.rominacortez.semana_5;

import android.location.Location;

public class Ubicacion {
    public double calculoDistancia(double latitudD, double longitudD){
        Location Pdestino = new Location("Punto Destino");
        Pdestino.setLatitude(latitudD);
        Pdestino.setLongitude(longitudD);

        Location Porigen = new Location("Punto Origen");
        Porigen.setLatitude(37.6094444);
        Porigen.setLongitude(-122.57527777777777);
        //Porigen.setLatitude(-33.437967);
        //Porigen.setLongitude(-70.6504);

        return Pdestino.distanceTo(Porigen);
    }
}
