package aiep.rominacortez.semana_5;

import java.util.ArrayList;

public class RegistroUsuarios {

    /*ArrayList<Usuarios> Registros = new ArrayList<Usuarios>();
    public void agregaUsuarios(Usuarios u){
        Registros.add(u);
    }
    public boolean existeUsuario(String correo, String pass){
        boolean existe = false;
        for(int i = 0; i<Registros.size(); i++) {
            if (Registros.get(i).getEmail().equals(correo)) {
                if (Registros.get(i).getContraseñaU().equals(pass)) {
                    //existe = true;
                    return true;
                    //break;
                }
            }
        }
        return existe;
    }*/

}
