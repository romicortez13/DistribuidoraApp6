package aiep.rominacortez.semana_5;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private static String NOMBREBASE = "GPS.bd";
    private static int VERSION =1;
    //private String nombre;

    public  BaseDatos(@Nullable Context context){
        super(context,NOMBREBASE,null,VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE Coordenadas(latitud varchar (20), longitud varchar (20))";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void agregarCoordenada(String lat, String lon){
        SQLiteDatabase db= getWritableDatabase();
        String sql =" INSERT INTO Coordenadas (latitud,longitud) values('"+lat+"','"+lon+"')";
        db.execSQL(sql);
    }
}


    /*public ArrayList <Usuarios> iniciaSesion(String email){
        ArrayList <Usuarios> datosLogin = new ArrayList<Usuarios>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * from Registros where correo = "+"'"+email+"'";
        //String sql = "SELECT * from Registros where correo = ""+email;
        Cursor cursor = db.rawQuery(sql,null);
        try{
            while(cursor.moveToNext()){
                Usuarios u = new Usuarios(cursor.getString(0), cursor.getString(1) );
                datosLogin.add(u);
            }
        }catch(Exception e){
            System.out.println("Error en "+e.getMessage());
        }
        return datosLogin;
    }*/