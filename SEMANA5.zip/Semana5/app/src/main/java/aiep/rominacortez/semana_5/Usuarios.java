package aiep.rominacortez.semana_5;

public class Usuarios {
    //String nombreU;
    //String apellidoU;
    //String celU;
    private String email;
    private String contraseñaU;

    public Usuarios() {  //constructor vacio//
    }

    public Usuarios(String email, String contraseñaU) {
        this.contraseñaU = contraseñaU;
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContraseñaU() {
        return contraseñaU;
    }

    public void setContraseñaU(String contraseñaU) {
        this.contraseñaU = contraseñaU;
    }

}
