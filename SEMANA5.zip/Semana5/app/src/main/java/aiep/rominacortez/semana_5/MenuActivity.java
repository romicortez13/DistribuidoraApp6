package aiep.rominacortez.semana_5;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MenuActivity extends AppCompatActivity {

    EditText vLatitud;
    EditText vLongitud;
    Button CerrarSesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        LocationManager LCM = (LocationManager) getSystemService(Context.LOCATION_SERVICE); // Objeto para poder obtener datos del GPS
        BaseDatos mibase = new BaseDatos(getBaseContext()); // crea objeto mibase para poder crear la base de datos y manejarla

        vLatitud = findViewById(R.id.VLat);
        vLongitud = findViewById(R.id.VLong);

        if (ActivityCompat.checkSelfPermission(MenuActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MenuActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MenuActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        else{
            Location lc = LCM.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(lc != null){
                double latitud = lc.getLatitude();
                double longitud = lc.getLongitude();
                System.out.println("Latitud es: "+latitud);
                System.out.println("Longitud es: "+longitud);
                mibase.agregarCoordenada(String.valueOf(latitud), String.valueOf(longitud));
                vLatitud.setText(String.valueOf(latitud));
                vLongitud.setText(String.valueOf(longitud));
            }
        }

        CerrarSesion = findViewById(R.id.CSesion);
        CerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}