package aiep.rominacortez.semana_5;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.firebase.firestore.FirebaseFirestore;

public class CompraProducto extends AppCompatActivity {

    Button Calcular;
    Button CerrarSes;
    EditText Vcompra;
    EditText Vdespacho;
    EditText Tcompra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_compra_producto);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //FusedLocationProviderClient FLC; //Objeto para
        LocationManager LCM = (LocationManager) getSystemService(Context.LOCATION_SERVICE); // Objeto para poder obtener datos del GPS

        BaseDatos mibase = new BaseDatos(getBaseContext()); // crea objeto mibase para poder crear la base de datos y manejarla
        FirebaseFirestore db = FirebaseFirestore.getInstance(); // crea objeto para manejo de base de datos

        Calcular = findViewById(R.id.button1);
        CerrarSes = findViewById(R.id.button2);

        Calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(CompraProducto.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(CompraProducto.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(CompraProducto.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                    return;
                }
                else{
                    Location lc = LCM.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if(lc != null){
                        double latitud = lc.getLatitude();
                        double longitud = lc.getLongitude();
                        System.out.println(""+latitud);
                        System.out.println(""+longitud);
                        mibase.agregarCoordenada(String.valueOf(latitud), String.valueOf(longitud));
                        /* --> se comenta rutina que realiza calculo de distancia entre dos puntos y realiza el calculo del despacho según las reglas del negocio
                        Ubicacion ub = new Ubicacion();
                        double dist = ub.calculoDistancia(latitud,longitud)/1000;
                        System.out.println("la distancia es: "+dist);
                        Vcompra = findViewById(R.id.Vcompra);
                        Vdespacho = findViewById(R.id.Vdespacho);
                        Tcompra = findViewById(R.id.Totcompra);
                        if (dist > 20) {
                            Toast.makeText(CompraProducto.this,"No aplica despacho a domicilio por compras sobre 20 Kms de distancia.",Toast.LENGTH_SHORT).show();
                        }
                        else{
                            CalculoDespacho cd = new CalculoDespacho();
                            Tcompra.setText(String.valueOf(cd.calcDespacho(dist,Double.parseDouble(Vcompra.getText().toString()))));
                        }*/
                    }
                }

                //double dist = ub.calculoDistancia(-33.5905556, -70.54472)/1000;

            }
        });

        CerrarSes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CompraProducto.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }



}