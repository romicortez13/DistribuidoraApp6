package aiep.rominacortez.semana_5;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText Email;
    EditText Contraseña;
    Button Registrar;
    EditText Icorreo;
    EditText Icontraseña;
    Button Isesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //BaseDatos mibase = new BaseDatos(getBaseContext()); -> esto si
        //mibase.agregarAnimal(getIntent().getExtras().getString("PasandoElTexto")); ---> ejemplo que no funcionó
        //mibase.agregarAnimal("juanito@gmail.com", "123456"); --> ejemplo llenado bd
        FirebaseAuth fba = FirebaseAuth.getInstance();
        //FirebaseFirestore db = FirebaseFirestore.getInstance(); -> esto si

        Registrar = findViewById(R.id.Registrar);
        Isesion   = findViewById(R.id.Ingresar);
        Registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Email = findViewById(R.id.Remail);
                Contraseña = findViewById(R.id.Rcontraseña);
                Usuarios user = new Usuarios(Email.getText().toString(),Contraseña.getText().toString());
                fba.createUserWithEmailAndPassword(user.getEmail(), user.getContraseñaU())
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(MainActivity.this,"Registro exitoso",Toast.LENGTH_SHORT).show();
                            }
                        });

                //mibase.agregarUsuario(user.getEmail(), user.getContraseñaU());
            }

        });
        Isesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Icorreo = findViewById(R.id.Lemail);
                Icontraseña = findViewById(R.id.Lcontraseña);
                fba.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                    }
                });
                fba.signInWithEmailAndPassword(Icorreo.getText().toString(),Icontraseña.getText().toString())
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    System.out.println("Inicio de sesión correcto");
                                    Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                                    startActivity(intent);
                                }
                                else{
                                    Toast.makeText(MainActivity.this,"No se puede iniciar sesión",Toast.LENGTH_SHORT).show();
                                }
                            }
                        });



                /*
                Icorreo = findViewById(R.id.Lemail);
                Icontraseña = findViewById(R.id.Lcontraseña);
                ArrayList<Usuarios> u = mibase.iniciaSesion(Icorreo.getText().toString());
                if(u != null) {
                    for (int i = 0; i < u.size(); i++) {
                        if (u.get(i).getContraseñaU().equals(Icontraseña.getText().toString())) {
                            System.out.println("Loggin correcto");
                            Intent intent = new Intent(MainActivity.this, CompraProducto.class);
                            startActivity(intent);
                        }
                    }
                }*/

            }
        });
    }
}
